# webapp-assignment1

Create As a user, I want to create an account by providing the following information.
  1.  Email Address
  2.  Password
  3. First Name
  4. Last Name

Update user information
As a user, I want to update my account information. I should only be allowed to update the following fields.
    1. First Name
    2. Last Name
    3. Password

Created a node application with mysql database.

Get user information

How to start a application

1. npm install

2. node demo_db_connection
